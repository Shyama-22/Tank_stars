TANK STARS GAME built using LibGDX.
